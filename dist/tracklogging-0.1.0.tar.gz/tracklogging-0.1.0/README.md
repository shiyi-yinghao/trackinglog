# TraceLog

TraceLog is a logging package for tracing function calls with error handling and email notification.

## Installation

You can install TraceLog using pip:

```bash
pip install tracelog

