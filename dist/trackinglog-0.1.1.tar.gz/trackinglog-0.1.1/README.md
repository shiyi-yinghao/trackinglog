# TrackLogging

TrackLogging is a logging package for tracing function calls with error handling and email notification.

## Installation

You can install TrackingLog using pip:

```bash
pip install trackinglog

```

## version History
0.1.0 Package Draft created
0.1.1 Decorator get_log and directly object creator get_logger creates. Add setup check decorator. Add p-functions(print and log)


## Feature in developing
Add error handling
Add print to log functions
Add public and private log
Add email notification
Add Kafka message notification
