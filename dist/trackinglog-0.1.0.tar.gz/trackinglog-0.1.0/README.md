# TrackLogging

TrackLogging is a logging package for tracing function calls with error handling and email notification.

## Installation

You can install TrackingLog using pip:

```bash
pip install trackinglog

